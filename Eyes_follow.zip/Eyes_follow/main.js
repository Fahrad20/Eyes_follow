let eye1 = document.querySelector('.a1');
let eye2 = document.querySelector('.b1');

function arcctg(x, y) {
    if (x > 0 && y > 0) {
        return Math.PI / 2 - Math.atan(x / y);
    } else if (x < 0 && y > 0) {
        return Math.PI / 2 - Math.atan(x / y);
    } else if (x < 0 && y < 0) {
        return Math.PI + Math.atan(y / x);
    } else {
        return 3 * Math.PI / 2 + Math.abs(Math.atan(x / y));
    }
}

document.onmousemove = (event) => {
    let x = event.x - 610;
    let y = event.y - 200;
    eye1.style = `transform: translate(-80%,150%) rotate(${57.2958 * arcctg(x,y)}deg)`;
    eye2.style = `transform: translate(-80%,150%) rotate(${57.2958 * arcctg(x-116,y)}deg)`;
}